import { motion } from "framer-motion";
import { useEffect, useState, useRef } from "react";
import { Award, Users, MapPin, Clock } from "lucide-react";

const stats = [
  { icon: Clock, value: 38, suffix: "+", label: "Years of Excellence", prefix: "" },
  { icon: Award, value: 100, suffix: "%", label: "Botswana-Owned", prefix: "" },
  { icon: MapPin, value: 50, suffix: "+", label: "Projects Delivered", prefix: "" },
  { icon: Users, value: 200, suffix: "+", label: "Skilled Professionals", prefix: "" },
];

const Counter = ({ target, suffix, prefix }: { target: number; suffix: string; prefix: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !started) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const duration = 1500;
    const steps = 40;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [started, target]);

  return (
    <div ref={ref} className="text-4xl md:text-5xl font-heading font-bold text-gold">
      {prefix}{count}{suffix}
    </div>
  );
};

const StatsSection = () => {
  return (
    <section className="section-padding bg-navy-gradient relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-gold blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-gold blur-3xl" />
      </div>
      <div className="container mx-auto relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <stat.icon className="w-8 h-8 text-gold mx-auto mb-4" />
              <Counter target={stat.value} suffix={stat.suffix} prefix={stat.prefix} />
              <p className="text-primary-foreground/60 mt-2 text-sm font-medium">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
