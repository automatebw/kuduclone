import { motion } from "framer-motion";

const clients = [
  "Botswana Telecommunications Corporation",
  "Debswana Diamond Company",
  "Botswana Defence Force",
  "Botswana Power Corporation",
  "Water Utilities Corporation",
  "MASCOM Wireless",
  "Orange Botswana",
  "BTC",
];

const ClientShowcase = () => {
  return (
    <section className="section-padding bg-muted/50">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-gold text-sm font-semibold tracking-wider uppercase">
            Trusted Partners
          </span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold mt-3 text-foreground">
            Partnerships with Big Names
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {clients.map((client, i) => (
            <motion.div
              key={client}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-xl p-6 flex items-center justify-center border border-border hover:border-gold/30 transition-colors min-h-[80px]"
            >
              <span className="text-foreground font-semibold text-sm text-center">{client}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ClientShowcase;
