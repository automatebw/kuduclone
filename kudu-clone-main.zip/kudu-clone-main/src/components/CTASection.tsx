import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Phone, Mail } from "lucide-react";

const CTASection = () => {
  return (
    <section className="section-padding bg-navy-gradient relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gold blur-3xl" />
      </div>
      <div className="container mx-auto relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-5xl font-heading font-bold text-primary-foreground mb-6">
            Ready to Connect <span className="text-gradient">Your Future?</span>
          </h2>
          <p className="text-primary-foreground/60 max-w-xl mx-auto mb-10 text-lg">
            Let's discuss how Kudu Communications can power your next telecommunications project.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-gold-gradient text-accent-foreground px-8 py-4 rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center gap-2 justify-center"
            >
              <Phone className="w-5 h-5" />
              Contact Us Today
            </Link>
            <a
              href="mailto:info@kuducomms.co.bw"
              className="border border-primary-foreground/30 text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors flex items-center gap-2 justify-center"
            >
              <Mail className="w-5 h-5" />
              info@kuducomms.co.bw
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
