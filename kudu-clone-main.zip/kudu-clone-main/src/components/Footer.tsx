import { Link } from "react-router-dom";
import { MapPin, Phone, Mail, Linkedin, Facebook } from "lucide-react";
import kuduLogo from "@/assets/kudu-logo.png";

const Footer = () => {
  return (
    <footer className="bg-navy-gradient pt-16 pb-8">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <img src={kuduLogo} alt="Kudu Communications" className="h-10 mb-4 bg-muted/80 rounded-lg p-1" />
            <p className="text-primary-foreground/50 text-sm leading-relaxed">
              Botswana's trusted telecommunications partner since 1986. Pursuit of Superior Performance.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-9 h-9 rounded-lg bg-navy-light flex items-center justify-center text-primary-foreground/60 hover:text-gold hover:bg-gold/10 transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-navy-light flex items-center justify-center text-primary-foreground/60 hover:text-gold hover:bg-gold/10 transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-bold text-primary-foreground mb-4 text-sm">Quick Links</h4>
            <ul className="space-y-2">
              {["Home", "About", "Services", "Industries", "Contact"].map((link) => (
                <li key={link}>
                  <Link
                    to={link === "Home" ? "/" : `/${link.toLowerCase()}`}
                    className="text-primary-foreground/50 text-sm hover:text-gold transition-colors"
                  >
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading font-bold text-primary-foreground mb-4 text-sm">Services</h4>
            <ul className="space-y-2">
              {["TETRA & Radio", "Fiber-Optic Networks", "Installations", "Training", "Audio Visual", "Maintenance"].map((s) => (
                <li key={s}>
                  <Link to="/services" className="text-primary-foreground/50 text-sm hover:text-gold transition-colors">
                    {s}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-bold text-primary-foreground mb-4 text-sm">Contact</h4>
            <ul className="space-y-3">
              <li className="flex gap-3 text-primary-foreground/50 text-sm">
                <MapPin className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                Plot 20688, Block 3, Gaborone, Botswana
              </li>
              <li className="flex gap-3 text-primary-foreground/50 text-sm">
                <Phone className="w-4 h-4 text-gold flex-shrink-0" />
                +267 395 9377
              </li>
              <li className="flex gap-3 text-primary-foreground/50 text-sm">
                <Mail className="w-4 h-4 text-gold flex-shrink-0" />
                info@kuducomms.co.bw
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 pt-6 text-center">
          <p className="text-primary-foreground/30 text-xs">
            © {new Date().getFullYear()} Kudu Communications (Pty) Ltd. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
