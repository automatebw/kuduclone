import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Pickaxe, Building2, Zap, ShieldCheck, Plane, Droplets, Radio, Landmark
} from "lucide-react";

const industries = [
  { icon: Pickaxe, name: "Mining", description: "Communication systems for remote mining operations" },
  { icon: Building2, name: "Government", description: "Secure networks for public sector agencies" },
  { icon: Zap, name: "Energy & Utilities", description: "Infrastructure for power and water utilities" },
  { icon: ShieldCheck, name: "Defence & Security", description: "Mission-critical communication systems" },
  { icon: Plane, name: "Aviation", description: "Air traffic and ground communication networks" },
  { icon: Droplets, name: "Environmental", description: "Monitoring and early warning systems" },
  { icon: Radio, name: "Telecommunications", description: "Network rollout for telecom operators" },
  { icon: Landmark, name: "Financial Services", description: "Secure connectivity for banking and finance" },
];

const IndustriesSection = () => {
  return (
    <section className="section-padding bg-muted/50">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-semibold tracking-wider uppercase">Industries</span>
          <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground">
            Sectors We Serve
          </h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            Trusted by organizations across Botswana's most critical industries.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {industries.map((industry, i) => (
            <motion.div
              key={industry.name}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="group bg-card rounded-xl p-6 text-center border border-border hover:border-gold/40 hover:shadow-lg transition-all duration-300 cursor-pointer"
            >
              <industry.icon className="w-10 h-10 text-gold mx-auto mb-3 group-hover:scale-110 transition-transform" />
              <h3 className="font-heading font-bold text-foreground text-sm md:text-base">{industry.name}</h3>
              <p className="text-muted-foreground text-xs mt-1 hidden md:block">{industry.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-10"
        >
          <Link
            to="/industries"
            className="text-gold font-semibold hover:underline"
          >
            View all industries →
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default IndustriesSection;
