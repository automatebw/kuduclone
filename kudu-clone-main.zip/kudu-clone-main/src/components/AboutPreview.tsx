import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle } from "lucide-react";

const highlights = [
  "Founded in 1986 by Botswana citizens",
  "Higher National Diploma-qualified leadership",
  "Partnerships with global technology brands",
  "Comprehensive in-house technical expertise",
];

const AboutPreview = () => {
  return (
    <section className="section-padding bg-background">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">About Kudu</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground leading-tight">
              Connecting Botswana <br />
              <span className="text-gradient">Since 1986</span>
            </h2>
            <p className="text-muted-foreground mt-6 leading-relaxed">
              Kudu Communications (Pty) Ltd. is a 100% citizen-owned company led by Managing Director Gabriel Lesego and Technical Director Dikeme Seitei. With over three decades of experience, we've built Botswana's reputation for excellence in telecommunications infrastructure.
            </p>
            <ul className="mt-6 space-y-3">
              {highlights.map((item) => (
                <li key={item} className="flex items-center gap-3 text-foreground">
                  <CheckCircle className="w-5 h-5 text-gold flex-shrink-0" />
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/about"
              className="mt-8 inline-flex items-center gap-2 bg-gold-gradient text-accent-foreground px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              Learn More About Us <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-navy-gradient rounded-2xl p-10 text-center">
              <div className="text-6xl md:text-8xl font-heading font-bold text-gold mb-2">38+</div>
              <p className="text-primary-foreground/70 text-lg">Years of Excellence</p>
              <div className="mt-8 grid grid-cols-2 gap-6">
                <div>
                  <div className="text-2xl font-heading font-bold text-gold">100%</div>
                  <p className="text-primary-foreground/60 text-xs mt-1">Citizen Owned</p>
                </div>
                <div>
                  <div className="text-2xl font-heading font-bold text-gold">ISO</div>
                  <p className="text-primary-foreground/60 text-xs mt-1">Certified Standards</p>
                </div>
              </div>
            </div>
            {/* Decorative element */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-gold/20 rounded-full blur-2xl" />
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gold/10 rounded-full blur-3xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutPreview;
