import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Radio, Cable, Wrench, GraduationCap, MonitorSpeaker, Settings, ArrowRight
} from "lucide-react";

const services = [
  {
    icon: Radio,
    title: "TETRA & Radio Systems",
    description: "Digital radio communication networks for mission-critical operations across mining, security, and government sectors.",
  },
  {
    icon: Cable,
    title: "Fiber-Optic Networks",
    description: "End-to-end fiber optic infrastructure design, installation, and maintenance for high-speed connectivity.",
  },
  {
    icon: Wrench,
    title: "Installations & Commissioning",
    description: "Professional installation of telecommunications equipment, towers, and network infrastructure.",
  },
  {
    icon: GraduationCap,
    title: "Training & Development",
    description: "Comprehensive technical training programs for telecommunications professionals and operators.",
  },
  {
    icon: MonitorSpeaker,
    title: "Audio Visual Solutions",
    description: "State-of-the-art AV systems for conference rooms, command centers, and public venues.",
  },
  {
    icon: Settings,
    title: "Maintenance & Support",
    description: "24/7 technical support and preventive maintenance to ensure maximum network uptime.",
  },
];

const ServicesGrid = () => {
  return (
    <section className="section-padding bg-background">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-semibold tracking-wider uppercase">What We Do</span>
          <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground">
            Our Core Services
          </h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            From design to deployment, we deliver comprehensive telecommunications and technology solutions tailored for Africa.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="group bg-card rounded-xl p-8 border border-border hover:border-gold/40 hover:shadow-xl hover:shadow-gold/5 transition-all duration-300"
            >
              <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-5 group-hover:bg-gold-gradient group-hover:scale-110 transition-all duration-300">
                <service.icon className="w-7 h-7 text-gold group-hover:text-accent-foreground transition-colors" />
              </div>
              <h3 className="text-xl font-heading font-bold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                {service.description}
              </p>
              <Link
                to="/services"
                className="text-gold text-sm font-semibold flex items-center gap-1 group-hover:gap-2 transition-all"
              >
                Learn more <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;
