import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  Target, Eye, Award, Users, Building, Wrench,
  CheckCircle, ArrowRight
} from "lucide-react";
import { Link } from "react-router-dom";

const timeline = [
  { year: "1986", title: "Company Founded", description: "Kudu Communications established as a 100% citizen-owned telecommunications company in Gaborone, Botswana." },
  { year: "1992", title: "First Major Contract", description: "Secured first government telecommunications infrastructure project with Botswana Defence Force." },
  { year: "2000", title: "TETRA System Pioneers", description: "Became the first company in Botswana to deploy TETRA digital radio systems for mission-critical communications." },
  { year: "2005", title: "Mining Sector Expansion", description: "Partnered with Debswana Diamond Company for comprehensive underground communication systems." },
  { year: "2010", title: "Fiber-Optic Division", description: "Launched dedicated fiber-optic infrastructure division, completing major backbone network projects." },
  { year: "2015", title: "Regional Growth", description: "Expanded operations across Southern Africa, delivering projects in Namibia and South Africa." },
  { year: "2020", title: "Smart Solutions", description: "Integrated IoT and smart monitoring solutions into environmental and utility sector projects." },
  { year: "2024", title: "38+ Years Strong", description: "Continuing to lead Botswana's telecommunications landscape with cutting-edge technology solutions." },
];

const leadership = [
  {
    name: "Gabriel Lesego",
    role: "Managing Director",
    bio: "Higher National Diploma in Electrical/Electronic Engineering. Over 30 years of experience in telecommunications management and strategic leadership across Botswana.",
    expertise: ["Strategic Planning", "Business Development", "Telecommunications Policy"],
  },
  {
    name: "Dikeme Seitei",
    role: "Technical Director",
    bio: "Higher National Diploma in Electrical/Electronic Engineering with extensive expertise in TETRA systems, fiber-optic networks, and radio frequency engineering.",
    expertise: ["TETRA Systems", "Fiber Optics", "RF Engineering"],
  },
];

const facilities = [
  { icon: Building, title: "Headquarters", description: "Modern offices at Plot 20688, Block 3, Gaborone with fully equipped workshops and testing facilities." },
  { icon: Wrench, title: "Technical Workshop", description: "In-house repair and assembly capabilities for telecommunications equipment and radio systems." },
  { icon: Users, title: "Training Center", description: "Dedicated training facility for operator certification and technical skills development programs." },
  { icon: Award, title: "Quality Lab", description: "Testing and quality assurance laboratory ensuring all installations meet international standards." },
];

const AboutPage = () => {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="bg-navy-gradient pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-gold blur-3xl" />
        </div>
        <div className="container mx-auto relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">About Us</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold text-primary-foreground mt-3">
              Our Story of <span className="text-gradient">Excellence</span>
            </h1>
            <p className="text-primary-foreground/60 mt-6 max-w-2xl text-lg leading-relaxed">
              For over 38 years, Kudu Communications has been at the forefront of Botswana's telecommunications revolution — 100% citizen-owned, 100% committed to excellence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section-padding bg-background">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-card rounded-2xl p-10 border border-border"
            >
              <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-6">
                <Target className="w-7 h-7 text-gold" />
              </div>
              <h2 className="text-2xl font-heading font-bold text-foreground mb-4">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                To provide superior telecommunications infrastructure and technology solutions that empower organizations across Botswana and Southern Africa, while nurturing local talent and maintaining the highest standards of quality and reliability.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-card rounded-2xl p-10 border border-border"
            >
              <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-6">
                <Eye className="w-7 h-7 text-gold" />
              </div>
              <h2 className="text-2xl font-heading font-bold text-foreground mb-4">Our Vision</h2>
              <p className="text-muted-foreground leading-relaxed">
                To be Southern Africa's most trusted telecommunications partner, recognised for innovation, reliability, and our unwavering commitment to connecting communities and driving economic growth through technology.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="section-padding bg-muted/50">
        <div className="container mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">Our Journey</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground">Company Timeline</h2>
          </motion.div>

          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-border md:-translate-x-0.5" />

            <div className="space-y-8 md:space-y-12">
              {timeline.map((item, i) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className={`relative flex flex-col md:flex-row ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"} items-start md:items-center gap-6 md:gap-0`}
                >
                  {/* Content */}
                  <div className={`ml-12 md:ml-0 md:w-1/2 ${i % 2 === 0 ? "md:pr-16 md:text-right" : "md:pl-16"}`}>
                    <div className="bg-card rounded-xl p-6 border border-border hover:border-gold/30 transition-colors">
                      <span className="text-gold font-heading font-bold text-lg">{item.year}</span>
                      <h3 className="font-heading font-bold text-foreground text-xl mt-1">{item.title}</h3>
                      <p className="text-muted-foreground text-sm mt-2 leading-relaxed">{item.description}</p>
                    </div>
                  </div>

                  {/* Dot */}
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 bg-gold rounded-full -translate-x-1/2 mt-8 md:mt-0 ring-4 ring-background" />

                  {/* Spacer for opposite side */}
                  <div className="hidden md:block md:w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="section-padding bg-background">
        <div className="container mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">Leadership</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground">Our Directors</h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {leadership.map((person, i) => (
              <motion.div
                key={person.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card rounded-2xl p-8 border border-border hover:border-gold/30 transition-colors"
              >
                <div className="w-20 h-20 bg-navy-gradient rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-2xl font-heading font-bold text-gold">
                    {person.name.split(" ").map(n => n[0]).join("")}
                  </span>
                </div>
                <h3 className="text-xl font-heading font-bold text-foreground">{person.name}</h3>
                <p className="text-gold text-sm font-semibold mt-1">{person.role}</p>
                <p className="text-muted-foreground text-sm mt-4 leading-relaxed">{person.bio}</p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {person.expertise.map(skill => (
                    <span key={skill} className="text-xs bg-gold/10 text-gold px-3 py-1 rounded-full font-medium">{skill}</span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="section-padding bg-muted/50">
        <div className="container mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">Capabilities</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground">Our Facilities</h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {facilities.map((facility, i) => (
              <motion.div
                key={facility.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-card rounded-xl p-8 border border-border text-center hover:border-gold/30 transition-colors"
              >
                <facility.icon className="w-10 h-10 text-gold mx-auto mb-4" />
                <h3 className="font-heading font-bold text-foreground">{facility.title}</h3>
                <p className="text-muted-foreground text-sm mt-2 leading-relaxed">{facility.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-gold blur-3xl" />
        </div>
        <div className="container mx-auto relative z-10 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl md:text-5xl font-heading font-bold text-primary-foreground mb-6">
              Want to Work <span className="text-gradient">With Us?</span>
            </h2>
            <p className="text-primary-foreground/60 max-w-xl mx-auto mb-10 text-lg">
              Join the growing list of organisations that trust Kudu Communications.
            </p>
            <Link to="/contact" className="bg-gold-gradient text-accent-foreground px-8 py-4 rounded-lg font-semibold hover:opacity-90 transition-opacity inline-flex items-center gap-2">
              Get in Touch <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AboutPage;
