import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  MapPin, Calendar, Users, TrendingUp, Radio, Cable,
  MonitorSpeaker, Wrench, ArrowRight, CheckCircle
} from "lucide-react";
import { Link } from "react-router-dom";

const projects = [
  {
    title: "Debswana Jwaneng Mine TETRA Network",
    client: "Debswana Diamond Company",
    location: "Jwaneng, Botswana",
    year: "2018 - Present",
    icon: Radio,
    category: "TETRA & Radio Systems",
    magnitude: "Large Scale",
    value: "Multi-Million Pula",
    description: "Designed and deployed a comprehensive TETRA digital radio communication network across Jwaneng Mine — one of the world's richest diamond mines. The system provides mission-critical voice and data communications for underground and surface operations.",
    scope: [
      "Full TETRA network design and RF planning",
      "Underground leaky feeder antenna systems",
      "Surface base station installations",
      "Dispatch console and control room setup",
      "Ongoing maintenance and 24/7 support",
    ],
    impact: "Improved mine safety communications by 95%, enabling real-time coordination across 500+ personnel.",
  },
  {
    title: "BDF National Communications Backbone",
    client: "Botswana Defence Force",
    location: "Nationwide, Botswana",
    year: "2015 - 2020",
    icon: Cable,
    category: "Fiber-Optic Networks",
    magnitude: "National Scale",
    value: "Major Government Contract",
    description: "Engineered and installed a secure fiber-optic communications backbone connecting key BDF installations across Botswana. This project established a resilient, encrypted communication network for national defence operations.",
    scope: [
      "Fiber-optic route survey and design",
      "300+ km fiber cable installation",
      "Secure switching and encryption systems",
      "Redundant network architecture",
      "Training of BDF technical personnel",
    ],
    impact: "Established the first secure high-speed communication link across all major BDF installations nationwide.",
  },
  {
    title: "Botswana Power Corporation SCADA Upgrade",
    client: "Botswana Power Corporation",
    location: "Multiple Sites, Botswana",
    year: "2020 - 2022",
    icon: MonitorSpeaker,
    category: "Audio Visual & Monitoring",
    magnitude: "Medium Scale",
    value: "Significant Contract",
    description: "Upgraded the SCADA (Supervisory Control and Data Acquisition) communication infrastructure for BPC's power distribution network, integrating modern telemetry and monitoring systems.",
    scope: [
      "SCADA communication link upgrades",
      "RTU (Remote Terminal Unit) installations",
      "Control center AV system modernisation",
      "Network redundancy improvements",
      "Operator training and certification",
    ],
    impact: "Reduced power outage response times by 60% and improved grid monitoring coverage to 98%.",
  },
  {
    title: "Water Utilities Corporation Telemetry Network",
    client: "Water Utilities Corporation",
    location: "Northern Botswana",
    year: "2021 - 2023",
    icon: Wrench,
    category: "Installations & Monitoring",
    magnitude: "Medium Scale",
    value: "Government Tender",
    description: "Implemented a comprehensive water telemetry and monitoring network across WUC's northern water distribution infrastructure, enabling real-time monitoring of water levels, flow rates, and pump station operations.",
    scope: [
      "Telemetry system design and installation",
      "Solar-powered remote monitoring stations",
      "Central monitoring dashboard deployment",
      "Communication link establishment (VHF/UHF)",
      "Preventive maintenance programme setup",
    ],
    impact: "Enabled real-time monitoring of 40+ water supply points, reducing water losses by 30%.",
  },
  {
    title: "MASCOM Wireless Tower Infrastructure",
    client: "MASCOM Wireless",
    location: "Rural Botswana",
    year: "2019 - 2021",
    icon: Radio,
    category: "Telecommunications Infrastructure",
    magnitude: "Large Scale",
    value: "Multi-Year Contract",
    description: "Supported MASCOM's rural network expansion by constructing and commissioning telecommunications tower sites across underserved regions of Botswana, bringing mobile connectivity to remote communities.",
    scope: [
      "Tower site construction and civil works",
      "Antenna system installations",
      "Power system installations (solar hybrid)",
      "Microwave backhaul link setup",
      "Site acceptance testing and handover",
    ],
    impact: "Extended mobile coverage to 15+ previously unconnected communities, serving over 50,000 residents.",
  },
];

const magnitudeColors: Record<string, string> = {
  "National Scale": "bg-destructive/10 text-destructive",
  "Large Scale": "bg-gold/10 text-gold",
  "Medium Scale": "bg-accent/10 text-accent-foreground",
};

const ProjectsPage = () => {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="bg-navy-gradient pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-gold blur-3xl" />
        </div>
        <div className="container mx-auto relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">Our Work</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold text-primary-foreground mt-3">
              Project <span className="text-gradient">Portfolio</span>
            </h1>
            <p className="text-primary-foreground/60 mt-6 max-w-2xl text-lg leading-relaxed">
              Explore our track record of delivering high-impact telecommunications and infrastructure projects across Botswana and Southern Africa.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="section-padding bg-background">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: TrendingUp, value: "50+", label: "Projects Completed" },
              { icon: Users, value: "20+", label: "Major Clients" },
              { icon: MapPin, value: "5+", label: "Countries" },
              { icon: Calendar, value: "38+", label: "Years Experience" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center bg-card rounded-xl p-6 border border-border"
              >
                <stat.icon className="w-8 h-8 text-gold mx-auto mb-3" />
                <div className="text-3xl font-heading font-bold text-foreground">{stat.value}</div>
                <p className="text-muted-foreground text-sm mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="section-padding bg-muted/50">
        <div className="container mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">Case Studies</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold mt-3 text-foreground">Featured Projects</h2>
          </motion.div>

          <div className="space-y-8">
            {projects.map((project, i) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="bg-card rounded-2xl border border-border overflow-hidden hover:border-gold/30 transition-colors"
              >
                <div className="p-8 md:p-10">
                  {/* Header */}
                  <div className="flex flex-wrap items-start gap-4 mb-6">
                    <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <project.icon className="w-7 h-7 text-gold" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-xl md:text-2xl font-heading font-bold text-foreground">{project.title}</h3>
                      <div className="flex flex-wrap items-center gap-3 mt-2">
                        <span className="text-muted-foreground text-sm">{project.client}</span>
                        <span className="text-border">•</span>
                        <span className="text-muted-foreground text-sm flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {project.location}
                        </span>
                        <span className="text-border">•</span>
                        <span className="text-muted-foreground text-sm flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {project.year}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <span className={`text-xs font-semibold px-3 py-1 rounded-full ${magnitudeColors[project.magnitude] || "bg-muted text-muted-foreground"}`}>
                        {project.magnitude}
                      </span>
                      <span className="text-xs font-medium px-3 py-1 rounded-full bg-navy/10 text-foreground">
                        {project.category}
                      </span>
                    </div>
                  </div>

                  <p className="text-muted-foreground leading-relaxed mb-6">{project.description}</p>

                  {/* Scope */}
                  <div className="mb-6">
                    <h4 className="font-heading font-bold text-foreground text-sm mb-3">Project Scope</h4>
                    <ul className="grid md:grid-cols-2 gap-2">
                      {project.scope.map(item => (
                        <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Impact */}
                  <div className="bg-gold/5 rounded-xl p-4 border border-gold/20">
                    <p className="text-sm">
                      <span className="font-semibold text-gold">Impact: </span>
                      <span className="text-foreground">{project.impact}</span>
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-gold blur-3xl" />
        </div>
        <div className="container mx-auto relative z-10 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl md:text-5xl font-heading font-bold text-primary-foreground mb-6">
              Start Your <span className="text-gradient">Next Project</span>
            </h2>
            <p className="text-primary-foreground/60 max-w-xl mx-auto mb-10 text-lg">
              Let's discuss how we can deliver results for your organisation.
            </p>
            <Link to="/contact" className="bg-gold-gradient text-accent-foreground px-8 py-4 rounded-lg font-semibold hover:opacity-90 transition-opacity inline-flex items-center gap-2">
              Contact Us <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ProjectsPage;
