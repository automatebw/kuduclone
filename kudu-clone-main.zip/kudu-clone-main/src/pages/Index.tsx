import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import StatsSection from "@/components/StatsSection";
import ServicesGrid from "@/components/ServicesGrid";
import IndustriesSection from "@/components/IndustriesSection";
import AboutPreview from "@/components/AboutPreview";
import ClientShowcase from "@/components/ClientShowcase";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <StatsSection />
      <ServicesGrid />
      <IndustriesSection />
      <AboutPreview />
      <ClientShowcase />
      <CTASection />
      <Footer />
    </div>
  );
};

export default Index;
