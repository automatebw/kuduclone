import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import {
  Radio, Cable, Wrench, GraduationCap, MonitorSpeaker, Settings,
  ChevronDown, CheckCircle
} from "lucide-react";
import { useState } from "react";

const services = [
  {
    icon: Radio,
    title: "TETRA & Digital Radio Systems",
    summary: "Mission-critical communication networks built for reliability in the harshest environments.",
    details: [
      "TETRA (Terrestrial Trunked Radio) network design and deployment",
      "Digital Mobile Radio (DMR) solutions",
      "Dispatch consoles and control room integration",
      "Coverage planning and RF optimization",
      "System integration with existing infrastructure",
      "24/7 monitoring and support",
    ],
    clients: ["Botswana Defence Force", "Debswana Diamond Company", "Department of Wildlife"],
  },
  {
    icon: Cable,
    title: "Fiber-Optic Network Infrastructure",
    summary: "High-capacity backbone networks connecting communities and businesses across Botswana.",
    details: [
      "Aerial and underground fiber optic cable installation",
      "FTTH (Fiber-to-the-Home) deployments",
      "Backbone network design and construction",
      "Splicing, testing, and commissioning",
      "OTDR testing and certification",
      "Network maintenance and fault resolution",
    ],
    clients: ["BTC", "MASCOM Wireless", "Orange Botswana"],
  },
  {
    icon: Wrench,
    title: "Installations & Commissioning",
    summary: "Professional deployment of telecommunications infrastructure from tower to terminal.",
    details: [
      "Telecommunications tower construction and rigging",
      "Base station equipment installation",
      "Microwave link installation and alignment",
      "Power systems (solar, generator, hybrid)",
      "Site surveys and feasibility studies",
      "As-built documentation and handover",
    ],
    clients: ["Botswana Power Corporation", "Water Utilities Corporation"],
  },
  {
    icon: GraduationCap,
    title: "Training & Capacity Building",
    summary: "Empowering teams with the technical knowledge to operate and maintain critical systems.",
    details: [
      "TETRA radio system operator training",
      "Fiber optic splicing and testing certification",
      "Network management and troubleshooting",
      "Safety and compliance training",
      "Customized corporate training programs",
      "On-site and classroom-based delivery",
    ],
    clients: ["Government ministries", "Mining operators", "Telecom operators"],
  },
  {
    icon: MonitorSpeaker,
    title: "Audio Visual Solutions",
    summary: "Integrated AV systems for modern command centers, boardrooms, and public spaces.",
    details: [
      "Video conferencing and collaboration systems",
      "Command center display walls",
      "Public address and intercom systems",
      "Digital signage solutions",
      "AV system design and integration",
      "Ongoing maintenance and support",
    ],
    clients: ["Parliament of Botswana", "Corporate headquarters", "Hotels & resorts"],
  },
  {
    icon: Settings,
    title: "Maintenance & Technical Support",
    summary: "Keeping your networks running with preventive care and rapid response capabilities.",
    details: [
      "Preventive maintenance programs",
      "24/7 emergency response and repair",
      "Network performance monitoring",
      "Spare parts management",
      "SLA-based support contracts",
      "Remote and on-site diagnostics",
    ],
    clients: ["All major telecom operators", "Mining companies", "Government agencies"],
  },
];

const ServiceCard = ({ service, index }: { service: typeof services[0]; index: number }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.08 }}
      className="bg-card rounded-xl border border-border overflow-hidden"
    >
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-8 flex items-start gap-5 text-left hover:bg-muted/30 transition-colors"
      >
        <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
          <service.icon className="w-7 h-7 text-gold" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-heading font-bold text-foreground">{service.title}</h3>
          <p className="text-muted-foreground text-sm mt-1">{service.summary}</p>
        </div>
        <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform mt-1 ${expanded ? "rotate-180" : ""}`} />
      </button>

      {expanded && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="px-8 pb-8 border-t border-border"
        >
          <div className="grid md:grid-cols-2 gap-8 pt-6">
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-3">What We Deliver</h4>
              <ul className="space-y-2">
                {service.details.map((detail) => (
                  <li key={detail} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                    {detail}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-3">Key Clients</h4>
              <ul className="space-y-2">
                {service.clients.map((client) => (
                  <li key={client} className="text-sm text-muted-foreground bg-muted rounded-lg px-3 py-2">
                    {client}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

const ServicesPage = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      {/* Hero */}
      <section className="bg-navy-gradient pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-gold text-sm font-semibold tracking-wider uppercase"
          >
            Our Services
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-heading font-bold text-primary-foreground mt-3"
          >
            Comprehensive <span className="text-gradient">Solutions</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-primary-foreground/60 mt-4 max-w-2xl mx-auto text-lg"
          >
            From TETRA radio networks to fiber optic infrastructure, we deliver end-to-end telecommunications excellence.
          </motion.p>
        </div>
      </section>

      {/* Services List */}
      <section className="section-padding bg-background">
        <div className="container mx-auto max-w-4xl space-y-4">
          {services.map((service, i) => (
            <ServiceCard key={service.title} service={service} index={i} />
          ))}
        </div>
      </section>

      <CTASection />
      <Footer />
    </div>
  );
};

export default ServicesPage;
