import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import {
  Pickaxe, Building2, Zap, ShieldCheck, Plane, Droplets, Radio, Landmark
} from "lucide-react";

const industries = [
  {
    icon: Pickaxe,
    name: "Mining",
    description: "Reliable communication systems for underground and open-pit mining operations, ensuring safety and productivity in remote locations.",
    clients: ["Debswana Diamond Company", "Morupule Coal Mine", "BCL Limited"],
    solutions: ["TETRA radio networks", "Underground leaky feeder systems", "Surface-to-underground communication"],
  },
  {
    icon: Building2,
    name: "Government & Public Sector",
    description: "Secure, scalable telecommunications infrastructure for government ministries, agencies, and public institutions.",
    clients: ["Ministry of Transport & Communications", "Botswana Police Service", "Department of Wildlife"],
    solutions: ["National radio networks", "E-government connectivity", "Emergency communication systems"],
  },
  {
    icon: Zap,
    name: "Energy & Utilities",
    description: "Critical communication infrastructure for power generation, transmission, and water distribution networks.",
    clients: ["Botswana Power Corporation", "Water Utilities Corporation"],
    solutions: ["SCADA communication links", "Fiber optic backbone", "Remote monitoring systems"],
  },
  {
    icon: ShieldCheck,
    name: "Defence & Security",
    description: "Mission-critical, encrypted communication systems for military and national security operations.",
    clients: ["Botswana Defence Force", "Directorate of Intelligence"],
    solutions: ["Tactical radio systems", "Secure voice & data networks", "Command & control integration"],
  },
  {
    icon: Plane,
    name: "Aviation & Transport",
    description: "Air traffic control and ground communication systems ensuring safe and efficient aviation operations.",
    clients: ["Civil Aviation Authority", "Air Botswana"],
    solutions: ["VHF/UHF radio systems", "Airport communication networks", "Navigation aids"],
  },
  {
    icon: Droplets,
    name: "Environmental Monitoring",
    description: "Early warning and monitoring systems for weather, flood, and environmental hazard management.",
    clients: ["Department of Meteorological Services", "UNDP Botswana"],
    solutions: ["Weather station networks", "Flood early warning systems", "Remote sensor connectivity"],
  },
  {
    icon: Radio,
    name: "Telecommunications",
    description: "Network infrastructure deployment and maintenance for mobile and fixed-line operators across Botswana.",
    clients: ["BTC", "MASCOM Wireless", "Orange Botswana"],
    solutions: ["Tower construction", "Fiber optic rollout", "Network maintenance"],
  },
  {
    icon: Landmark,
    name: "Financial Services",
    description: "Secure, high-availability connectivity solutions for banks and financial institutions.",
    clients: ["Bank of Botswana", "First National Bank", "Stanbic Bank"],
    solutions: ["Branch connectivity", "Data center networking", "Secure communications"],
  },
];

const IndustriesPage = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      {/* Hero */}
      <section className="bg-navy-gradient pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-gold text-sm font-semibold tracking-wider uppercase"
          >
            Industries We Serve
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-heading font-bold text-primary-foreground mt-3"
          >
            Powering Every <span className="text-gradient">Sector</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-primary-foreground/60 mt-4 max-w-2xl mx-auto text-lg"
          >
            Trusted by Botswana's most critical industries for over 38 years.
          </motion.p>
        </div>
      </section>

      {/* Industry Cards */}
      <section className="section-padding bg-background">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-6">
            {industries.map((industry, i) => (
              <motion.div
                key={industry.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="bg-card rounded-xl border border-border p-8 hover:border-gold/40 hover:shadow-lg transition-all"
              >
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-12 h-12 bg-gold/10 rounded-xl flex items-center justify-center">
                    <industry.icon className="w-6 h-6 text-gold" />
                  </div>
                  <h3 className="text-xl font-heading font-bold text-foreground">{industry.name}</h3>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5">{industry.description}</p>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-2">Solutions</h4>
                    <ul className="space-y-1">
                      {industry.solutions.map((s) => (
                        <li key={s} className="text-xs text-muted-foreground">• {s}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-2">Key Clients</h4>
                    <ul className="space-y-1">
                      {industry.clients.map((c) => (
                        <li key={c} className="text-xs text-muted-foreground">• {c}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
      <Footer />
    </div>
  );
};

export default IndustriesPage;
