import { useState } from "react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  MapPin, Phone, Mail, Clock, Send, Linkedin, Facebook,
  CheckCircle, AlertCircle
} from "lucide-react";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be under 100 characters"),
  email: z.string().trim().email("Please enter a valid email").max(255, "Email must be under 255 characters"),
  phone: z.string().trim().max(20, "Phone number too long").optional().or(z.literal("")),
  company: z.string().trim().max(100, "Company name too long").optional().or(z.literal("")),
  subject: z.string().trim().min(1, "Subject is required").max(200, "Subject must be under 200 characters"),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(2000, "Message must be under 2000 characters"),
});

type ContactForm = z.infer<typeof contactSchema>;

const contactInfo = [
  {
    icon: MapPin,
    title: "Visit Us",
    details: ["Plot 20688, Block 3", "Gaborone, Botswana"],
  },
  {
    icon: Phone,
    title: "Call Us",
    details: ["+267 395 9377", "+267 395 9378"],
  },
  {
    icon: Mail,
    title: "Email Us",
    details: ["info@kuducomms.co.bw", "sales@kuducomms.co.bw"],
  },
  {
    icon: Clock,
    title: "Working Hours",
    details: ["Mon – Fri: 08:00 – 17:00", "Sat – Sun: Closed"],
  },
];

const ContactPage = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ContactForm>({
    name: "",
    email: "",
    phone: "",
    company: "",
    subject: "",
    message: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof ContactForm, string>>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name as keyof ContactForm]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = contactSchema.safeParse(formData);

    if (!result.success) {
      const fieldErrors: Partial<Record<keyof ContactForm, string>> = {};
      result.error.errors.forEach(err => {
        const field = err.path[0] as keyof ContactForm;
        if (!fieldErrors[field]) fieldErrors[field] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setSubmitted(true);
    toast({
      title: "Message Sent!",
      description: "We'll get back to you within 24 hours.",
    });
  };

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="bg-navy-gradient pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-gold blur-3xl" />
        </div>
        <div className="container mx-auto relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="text-gold text-sm font-semibold tracking-wider uppercase">Contact Us</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold text-primary-foreground mt-3">
              Let's <span className="text-gradient">Connect</span>
            </h1>
            <p className="text-primary-foreground/60 mt-6 max-w-2xl text-lg leading-relaxed">
              Ready to start your next project? Get in touch with our team of telecommunications experts.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="section-padding bg-background">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-16">
            {contactInfo.map((info, i) => (
              <motion.div
                key={info.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-card rounded-xl p-6 border border-border text-center hover:border-gold/30 transition-colors"
              >
                <info.icon className="w-8 h-8 text-gold mx-auto mb-3" />
                <h3 className="font-heading font-bold text-foreground text-sm mb-2">{info.title}</h3>
                {info.details.map(d => (
                  <p key={d} className="text-muted-foreground text-xs">{d}</p>
                ))}
              </motion.div>
            ))}
          </div>

          {/* Form + Map Grid */}
          <div className="grid lg:grid-cols-2 gap-10">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl md:text-3xl font-heading font-bold text-foreground mb-6">Send Us a Message</h2>

              {submitted ? (
                <div className="bg-card rounded-2xl p-10 border border-gold/30 text-center">
                  <CheckCircle className="w-16 h-16 text-gold mx-auto mb-4" />
                  <h3 className="text-xl font-heading font-bold text-foreground mb-2">Thank You!</h3>
                  <p className="text-muted-foreground">Your message has been received. Our team will respond within 24 hours.</p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({ name: "", email: "", phone: "", company: "", subject: "", message: "" });
                    }}
                    className="mt-6 text-gold font-semibold hover:underline"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1.5">
                        Full Name <span className="text-destructive">*</span>
                      </label>
                      <input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className={`w-full px-4 py-3 rounded-lg bg-card border ${errors.name ? "border-destructive" : "border-border"} text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors`}
                        placeholder="Your full name"
                      />
                      {errors.name && <p className="text-destructive text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.name}</p>}
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-foreground mb-1.5">
                        Email <span className="text-destructive">*</span>
                      </label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`w-full px-4 py-3 rounded-lg bg-card border ${errors.email ? "border-destructive" : "border-border"} text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors`}
                        placeholder="your@email.com"
                      />
                      {errors.email && <p className="text-destructive text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.email}</p>}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-1.5">Phone</label>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                        placeholder="+267 ..."
                      />
                    </div>
                    <div>
                      <label htmlFor="company" className="block text-sm font-medium text-foreground mb-1.5">Company</label>
                      <input
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                        placeholder="Company name"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-foreground mb-1.5">
                      Subject <span className="text-destructive">*</span>
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 rounded-lg bg-card border ${errors.subject ? "border-destructive" : "border-border"} text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors`}
                    >
                      <option value="">Select a subject</option>
                      <option value="TETRA & Radio Systems">TETRA & Radio Systems</option>
                      <option value="Fiber-Optic Networks">Fiber-Optic Networks</option>
                      <option value="Installations">Installations & Commissioning</option>
                      <option value="Training">Training & Development</option>
                      <option value="Audio Visual">Audio Visual Solutions</option>
                      <option value="Maintenance">Maintenance & Support</option>
                      <option value="General Enquiry">General Enquiry</option>
                      <option value="Partnership">Partnership Opportunity</option>
                    </select>
                    {errors.subject && <p className="text-destructive text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.subject}</p>}
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1.5">
                      Message <span className="text-destructive">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 rounded-lg bg-card border ${errors.message ? "border-destructive" : "border-border"} text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors resize-none`}
                      placeholder="Tell us about your project..."
                    />
                    {errors.message && <p className="text-destructive text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.message}</p>}
                    <p className="text-muted-foreground text-xs mt-1">{formData.message.length}/2000</p>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gold-gradient text-accent-foreground px-8 py-4 rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Send Message
                  </button>
                </form>
              )}
            </motion.div>

            {/* Map */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex flex-col gap-6"
            >
              <h2 className="text-2xl md:text-3xl font-heading font-bold text-foreground">Find Us</h2>
              <div className="rounded-2xl overflow-hidden border border-border flex-1 min-h-[400px]">
                <iframe
                  title="Kudu Communications Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3660.1!2d25.9!3d-24.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDM5JzAwLjAiUyAyNcKwNTQnMDAuMCJF!5e0!3m2!1sen!2sbw!4v1"
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: "400px" }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>

              {/* Social Links */}
              <div className="bg-card rounded-xl p-6 border border-border">
                <h3 className="font-heading font-bold text-foreground text-sm mb-3">Follow Us</h3>
                <div className="flex gap-3">
                  <a
                    href="#"
                    aria-label="LinkedIn"
                    className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-gold hover:bg-gold/10 transition-colors"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                  <a
                    href="#"
                    aria-label="Facebook"
                    className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-gold hover:bg-gold/10 transition-colors"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ContactPage;
